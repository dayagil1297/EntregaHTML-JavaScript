
 
$(document).ready( function () {
    $('#data_table').DataTable({
        //para cambiar el lenguaje a español
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing":"Procesando...",
        }
    });
});


function registrado(){
	confirm("Su registro ha sido exitoso.");
}

	$('#agregar_registro').click(function() {
	var nombre = document.getElementById('nombre').value;
	var apellido = document.getElementById('apellido').value;
	var ciudad = document.getElementById('ciudad').value;
	var pais = document.getElementById('pais').value;


	tabla.row.add([
		dt.rows().count()+1,
		nombre,
		apellido,
		ciudad,
		pais,
	] ).draw( false );

	$($('table').find('tbody').find('tr')[$('table').rows().count()-1]).find('td')[0].setAttribute('align', 'center')
	});

	/*
    $(document).ready(function() {
    var t = $('#example').DataTable();
    var counter = 1;
 
    $('#addRow').on( 'click', function () {
        t.row.add( [
            counter +'.1',
            counter +'.2',
            counter +'.3',
            counter +'.4',
            counter +'.5'
        ] ).draw( false );
 
        counter++;
    } );
 
    // Automatically add a first row of data
    $('#addRow').click();
} );
